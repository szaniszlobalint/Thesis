#!/bin/bash

exec npm run start

exit $?
